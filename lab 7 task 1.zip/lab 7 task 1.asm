.model small
.stack 100h
.data
.code
main proc

mov al, 5     
mov bl, 4     
mul bl         

mov bl, 10
div bl        

mov dl, al
add dl, 48
mov ah, 2
int 21h

mov dl, ah
add dl, 48
mov ah, 2
int 21h

mov ah,4ch
int 21h

main endp
end main