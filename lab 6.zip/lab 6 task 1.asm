.model small
.stack 100h
.data
name db 'Full Name: Saba Khan$'
sap  db 'SAP ID: 69478$'
batch db 'Batch: SE3-1$'
program db 'Program: BSSE Semester 3$'

.code
main proc

mov ax, @data
mov ds, ax

mov dx, offset name
mov ah, 9
int 21h

mov dl, 10
mov ah, 2
int 21h
mov dl, 13
int 21h

mov dx, offset sap
mov ah, 9
int 21h

mov dl, 10
mov ah, 2
int 21h
mov dl, 13
int 21h

mov dx, offset batch
mov ah, 9
int 21h

mov dl, 10
mov ah, 2
int 21h
mov dl, 13
int 21h

mov dx, offset program
mov ah, 9
int 21h

mov ah,4ch
int 21h

main endp
end main
